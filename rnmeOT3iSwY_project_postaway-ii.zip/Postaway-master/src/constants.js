export const DB_NAME = "postaway";
